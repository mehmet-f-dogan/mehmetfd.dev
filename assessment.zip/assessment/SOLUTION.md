# Technical Assessment Solution

**Candidate Name**: Mehmet Furkan Dogan
**Date**: 2025/10/31
**Time Spent**: 3 hours

---

## Executive Summary

The codebase shows a good foundational structure but suffers from a few serious backend level issues that could impact production stability. The most critical problems involved multiple instances of `PrismaClient` being created, per request instantiation of background services, and unbounded in-memory caches. These would lead to database connection exhaustion, memory leaks, and performance degradation. I refactored key services (`Prisma`, `AIService`, `QueueService`) into singletons, introduced a bounded cache, and ensured controlled background polling. After fixes, the system is stable, efficient, and ready for further scaling improvements.

---

## Part 1: Issues Found & Fixed

### Issue #1: Multiple PrismaClient Instances

**Severity**: Critical
**Category**: Resource / Database Connection
**Location**: `lib/prisma.ts`

**Description**:

```
Each reload or request created a new PrismaClient instance.
```

**Impact**:

```
Leads to connection exhaustion, causing the app to crash or block on DB connections.
```

**Root Cause**:

```
No global singleton guard for PrismaClient initialization.
```

**Solution**:

```
Implemented a global PrismaClient singleton pattern using `globalThis` to ensure one instance is reused.
```

**Trade-offs**:

```
None significant; this is a well-known safe pattern for Next.js.
```

---

### Issue #2: Per-Request Service Instantiation

**Severity**: High
**Category**: Concurrency / Architecture
**Location**: `server/context.ts`, `services/ai-service.ts`, `services/queue-service.ts`

**Description**:

```
Each request initialized new AI and Queue services. The queue service auto started its polling on instantiation, resulting in multiple concurrent pollers.
```

**Impact**:

```
High CPU usage, duplicate job processing, and potential data inconsistencies.
```

**Root Cause**:

```
Services were not implemented as singletons; they were constructed in the request lifecycle.
```

**Solution**:

```
Converted AIService and QueueService to singletons. QueueService now exposes `start()` / `stop()` lifecycle methods.
```

**Trade-offs**:

```
For multi-instance deployments, background jobs should move to a separate worker.
```

---

### Issue #3: Unbounded Memory Cache

**Severity**: High
**Category**: Memory / Performance
**Location**: `services/ai-service.ts`

**Description**:

```
AIService cached responses in an unbounded Map, risking memory exhaustion under heavy load.
```

**Impact**:

```
Possible memory leaks and OOM crashes.
```

**Root Cause**:

```
No eviction policy or cache TTL.
```

**Solution**:

```
Added a simple bounded LRU cache (max 100 items, 1 hour TTL).
```

**Trade-offs**:

```
Simple O(n) eviction acceptable for small caches; can scale to Redis for production.
```

---

### Issue #4: Queue Polling Error Storms

**Severity**: Medium
**Category**: Reliability / Architecture
**Location**: `services/queue-service.ts`

**Description**:

```
Queue polling ran continuously without backoff, causing repeated DB queries even during failures.
```

**Impact**:

```
Error storms and unnecessary DB load under transient failures.
```

**Root Cause**:

```
Lack of backoff or retry strategy.
```

**Solution**:

```
Wrapped polling loop with try/catch and controlled interval; recommended migration to a production level job queue.
```

**Trade-offs**:

```
Still a simple in-process solution; external queues are preferred for scale.
```

---

### Issue #5: Auth Header Extraction

**Location**: `server/context.ts`

**Description**:

```
This might be an issue related with Next.js but my server couldn't access headers so I had to change the way to access to the token a bit.
```

---

## Part 2: Architecture Analysis

### Current Architecture

```
Next.js app with Prisma ORM, AI service integration, and an internal polling queue for background processing. API routes trigger AI tasks which enqueue background jobs processed periodically.
```

### Strengths

```
- Clean modular structure.
- Clear separation of concerns.
- Use of TypeScript and Prisma adds type safety.
```

### Weaknesses

```
- Lack of singleton management and lifecycle control.
- No clear queue or job persistence layer.
- No monitoring or metrics.
```

---

## Part 3: Scaling Recommendations

**Database Layer**:

```
Use connection pooling. Add indexes, slow query logging, and DB health monitoring.
```

**Application Layer**:

```
Stateless API servers behind a load balancer. Use Redis for caching and rate limiting.
```

**Queue/Background Jobs**:

```
Move to AWS SQS + Lambda for distributed reliability.
```

**AI Integration**:

```
Add per user rate limits and request deduplication to reduce API costs.
```

**Monitoring & Observability**:

```
Track: request rate, latency (p95/p99), error count, memory usage, DB connections, queue length, AI token usage.
Set alerts for high error rate, slow requests, or OOM restarts.
```

---

## Part 4: Production Readiness

**Infrastructure**:

```
- [ ] Dockerized services
- [ ] Health checks and readiness probes
- [ ] Environment validation on startup
```

**Monitoring**:

```
- [ ] Prometheus/Grafana dashboards
- [ ] Log aggregation (Loki/ELK)
```

**Security**:

```
- [ ] Secret management (Vault / environment vars)
- [ ] JWT rotation and expiry validation
```

**Testing**:

```
- [ ] Unit tests for AIService and QueueService
- [ ] Integration tests for DB and job flow
```

---

## Part 5: AI Integration Review

### Current Prompt Engineering

```
Prompt structure is functional but lacks system-level context injection and consistent instruction formatting.
```

### Cost Optimization Opportunities

```
- Cache repeated requests (deduplicate identical prompts)
- Lower token usage and temperature
- Use streaming responses when possible
```

### Improvements Made

```
- Introduced cache bounding and TTL
- Singleton Anthropic client to reduce overhead
```

---

## Part 6: Additional Observations

### Code Quality

```
Readable and modular. Missing runtime validation and consistent error handling.
```

### Testing Strategy

```
Would add tests for queue processing, AIService caching, and Prisma data operations.
```

### Documentation

```
Minimal inline documentation. Recommend adding README sections for architecture overview and environment setup.
```

---

## Part 7: Time Management & Priorities

### How did you spend your time?

```
- Setup & exploration: 30 minutes
- Issue identification: 45 minutes
- Implementing fixes: 60 minutes
- Testing: 15 minutes
- Documentation: 30 minutes
```

### Prioritization

```
Focused on production impacting issues: DB connection exhaustion, memory leaks, and queue duplication.
```

### What would you do with more time?

```
Add Redis backed job queue, proper retry logic, unit tests, and structured logging.
```

---

## Part 8: Questions & Discussion Points

### Questions for the team

```
1. Should the background job queue persist tasks between deployments?
2. Are AI calls expected to be synchronous (user-facing) or async (background)?
3. Any constraints on external service usage (Redis, SQS)?
```

### Areas for discussion

```
- Moving background jobs out of the web process.
- Implementing distributed cache and monitoring.
```

---

## Summary Checklist

- [x] Critical issues identified and fixed
- [x] Performance improvements implemented
- [x] Memory leaks addressed
- [x] Concurrency issues resolved
- [x] Security concerns noted
- [x] Scaling strategy documented
- [x] Code tested and working
- [x] Trade offs documented

---

## Closing Thoughts

```
The project demonstrates solid fundamentals but required critical fixes for safe production operation. I focused on stabilizing core services and improving resource management. With some infrastructure additions, especially around queueing, monitoring, and testing, it can scale confidently and operate cost effectively.
```
