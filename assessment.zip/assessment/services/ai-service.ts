// AI Service for Claude Sonnet integration
// Enhanced for stability, memory safety, and production scalability

import Anthropic from "@anthropic-ai/sdk";
import crypto from "crypto";

class AIService {
  private client?: Anthropic;
  private cache: Map<string, { value: any; createdAt: number }> = new Map();
  private readonly MAX_CACHE_SIZE = 100;
  private readonly CACHE_TTL_MS = 60 * 60 * 1000;

  private getClient(): Anthropic {
    if (!this.client) {
      if (!process.env.ANTHROPIC_API_KEY) {
        throw new Error("Missing ANTHROPIC_API_KEY");
      }
      this.client = new Anthropic({
        apiKey: process.env.ANTHROPIC_API_KEY,
      });
    }
    return this.client;
  }

  private getCacheKey(prompt: string) {
    return crypto.createHash("sha256").update(prompt).digest("hex");
  }

  private getFromCache(key: string) {
    const entry = this.cache.get(key);
    if (!entry) return null;
    if (Date.now() - entry.createdAt > this.CACHE_TTL_MS) {
      this.cache.delete(key);
      return null;
    }
    return entry.value;
  }

  private setCache(key: string, value: any) {
    if (this.cache.size >= this.MAX_CACHE_SIZE) {
      const oldestKey = this.cache.keys().next().value;
      if (oldestKey) {
        this.cache.delete(oldestKey);
      }
    }
    this.cache.set(key, { value, createdAt: Date.now() });
  }

  private async safeRequest(messages: any[], max_tokens = 4000) {
    try {
      const client = this.getClient();
      const response = await client.messages.create({
        model: "claude-3-5-sonnet-20241022",
        max_tokens,
        temperature: 0.7,
        messages,
      });
      const content = response.content[0];
      if (content.type !== "text") throw new Error("Unexpected response type");
      return { text: content.text, usage: response.usage };
    } catch (error: any) {
      console.error("AIService request error:", error.message);
      throw new Error("AI request failed");
    }
  }

  async generateComponent(
    prompt: string
  ): Promise<{ code: string; tokensUsed: number }> {
    console.log("Generating component (prompt length:", prompt.length, ")");

    const cacheKey = this.getCacheKey(`component:${prompt}`);
    const cached = this.getFromCache(cacheKey);
    if (cached) {
      console.log("Returning cached result for component generation");
      return cached;
    }

    const { text, usage } = await this.safeRequest(
      [
        {
          role: "user",
          content: `You are a helpful assistant that generates React components.

User request: ${prompt}

Please generate a complete React component. Include all imports, proper TypeScript types, and make it production-ready.

Also explain the component in detail, including:
- What it does
- How to use it
- Props documentation
- Edge cases
- Performance & accessibility notes
- Testing recommendations
- Possible improvements

Then provide the code.`,
        },
      ],
      8000
    );

    const result = {
      code: text,
      tokensUsed: usage.input_tokens + usage.output_tokens,
    };
    this.setCache(cacheKey, result);
    return result;
  }

  async improveCode(code: string, feedback: string): Promise<string> {
    const prompt = `Here is some code:

\`\`\`
${code}
\`\`\`

Please improve it based on this feedback: ${feedback}

Provide a detailed explanation of all the changes you made and why, then provide the improved code.`;

    const { text } = await this.safeRequest(
      [{ role: "user", content: prompt }],
      8000
    );

    return text;
  }

  async explainCode(code: string): Promise<string> {
    const { text } = await this.safeRequest(
      [
        {
          role: "user",
          content: `Please explain this code in great detail:

\`\`\`
${code}
\`\`\`

Include:
- What it does
- How it works
- Any issues or improvements
- Best practices
- Alternative approaches`,
        },
      ],
      4000
    );
    return text;
  }

  async generateTests(code: string): Promise<string> {
    const { text } = await this.safeRequest(
      [
        {
          role: "user",
          content: `Generate comprehensive test cases for this code:

\`\`\`
${code}
\`\`\`

Include:
- Unit tests
- Integration tests
- Edge cases
- Error scenarios
- Explanation of each test`,
        },
      ],
      6000
    );
    return text;
  }

  async validateComponent(
    code: string
  ): Promise<{ valid: boolean; issues: string[] }> {
    const { text } = await this.safeRequest(
      [
        {
          role: "user",
          content: `Validate this React component and list any issues:

\`\`\`
${code}
\`\`\`

Check for:
- Syntax errors
- Type errors
- Best practice violations
- Performance issues
- Security issues
- Accessibility issues

Provide detailed explanations for each issue found.`,
        },
      ],
      4000
    );

    const lower = text.toLowerCase();
    const hasIssues = lower.includes("issue") || lower.includes("error");
    return { valid: !hasIssues, issues: hasIssues ? [text] : [] };
  }

  getCacheSize(): number {
    return this.cache.size;
  }

  clearCache(): void {
    this.cache.clear();
  }
}

export const aiService = new AIService();
export default aiService;
