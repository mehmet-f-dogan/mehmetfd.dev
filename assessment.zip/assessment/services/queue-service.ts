// Improved Queue Service for background job processing
// Fixes: multiple timers, race conditions, unbounded memory, no backoff, unsafe retries

import { prisma } from "../lib/prisma";
import aiService from "./ai-service";

interface QueueJob {
  id: string;
  type: string;
  payload: any;
  status: string;
  attempts: number;
  maxAttempts: number;
}

class QueueService {
  private processing = false;
  private pollInterval: NodeJS.Timeout | null = null;
  private processedJobs = new Set<string>();
  private failedJobsCache: Array<{
    id: string;
    error: string;
    timestamp: number;
  }> = [];
  private running = false;

  private readonly POLL_INTERVAL_MS = 3000; // reduced DB pressure
  private readonly MAX_FAILED_CACHE = 100;
  private readonly BASE_BACKOFF_MS = 5000; // exponential backoff base delay

  /** Start polling safely (idempotent) */
  public start() {
    if (this.running) return;
    this.running = true;
    console.log("[QueueService] Polling started");

    this.pollInterval = setInterval(async () => {
      try {
        await this.processNextJob();
      } catch (err) {
        console.error("[QueueService] Polling error:", err);
      }
    }, this.POLL_INTERVAL_MS);
  }

  /** Stop background polling */
  public stop() {
    if (this.pollInterval) clearInterval(this.pollInterval);
    this.pollInterval = null;
    this.running = false;
    console.log("[QueueService] Polling stopped");
  }

  /** Add a new background job to the queue */
  async addJob(job: { type: string; payload: any; priority?: number }) {
    return prisma.queueJob.create({
      data: {
        type: job.type,
        payload: job.payload,
        priority: job.priority || 0,
        status: "pending",
        attempts: 0,
        maxAttempts: 3,
        scheduledFor: new Date(),
      },
    });
  }

  /** Core polling loop */
  private async processNextJob() {
    if (this.processing) return;
    this.processing = true;

    try {
      const job = await prisma.queueJob.findFirst({
        where: { status: "pending", scheduledFor: { lte: new Date() } },
        orderBy: [{ priority: "desc" }, { createdAt: "asc" }],
      });

      if (!job) return;

      // Skip if already processed in this runtime
      if (this.processedJobs.has(job.id)) return;

      // Mark as processing (atomic enough for single instance)
      await prisma.queueJob.update({
        where: { id: job.id },
        data: { status: "processing", startedAt: new Date() },
      });

      this.processedJobs.add(job.id);

      try {
        await this.executeJob(job);

        await prisma.queueJob.update({
          where: { id: job.id },
          data: { status: "completed", completedAt: new Date() },
        });
      } catch (err: any) {
        await this.handleJobFailure(job, err);
      }
    } catch (err) {
      console.error("[QueueService] Unexpected error:", err);
    } finally {
      this.processing = false;
    }
  }

  /** Execute a job by type */
  private async executeJob(job: QueueJob) {
    // Add a timeout to prevent hanging forever
    const TIMEOUT_MS = 60000;
    const jobPromise = this.runJobType(job);
    const timeout = new Promise((_, reject) =>
      setTimeout(() => reject(new Error("Job timed out")), TIMEOUT_MS)
    );
    await Promise.race([jobPromise, timeout]);
  }

  /** Handle retry & failure logic */
  private async handleJobFailure(job: QueueJob, error: any) {
    const message = error instanceof Error ? error.message : String(error);
    const attempts = job.attempts + 1;

    this.failedJobsCache.push({
      id: job.id,
      error: message,
      timestamp: Date.now(),
    });
    if (this.failedJobsCache.length > this.MAX_FAILED_CACHE) {
      this.failedJobsCache.shift();
    }

    if (attempts < job.maxAttempts) {
      // Exponential backoff retry delay
      const delay = this.BASE_BACKOFF_MS * Math.pow(2, attempts - 1);
      await prisma.queueJob.update({
        where: { id: job.id },
        data: {
          status: "pending",
          attempts,
          error: message,
          scheduledFor: new Date(Date.now() + delay),
        },
      });
      console.warn(`[QueueService] Retrying job ${job.id} in ${delay / 1000}s`);
    } else {
      await prisma.queueJob.update({
        where: { id: job.id },
        data: {
          status: "failed",
          attempts,
          error: message,
          completedAt: new Date(),
        },
      });
      console.error(
        `[QueueService] Job ${job.id} permanently failed after ${attempts} attempts.`
      );
    }
  }

  /** Actual handlers for each job type */
  private async runJobType(job: QueueJob) {
    switch (job.type) {
      case "ai_generation":
        return this.handleAIGeneration(job);
      case "ai_improvement":
        return this.handleAIImprovement(job);
      case "ai_validation":
        return this.handleAIValidation(job);
      default:
        console.warn(`[QueueService] Unknown job type: ${job.type}`);
    }
  }

  private async handleAIGeneration(job: QueueJob) {
    const { generationId, prompt } = job.payload;
    try {
      const result = await aiService.generateComponent(prompt);
      await prisma.generation.update({
        where: { id: generationId },
        data: {
          status: "completed",
          result: result.code,
          tokensUsed: result.tokensUsed,
          completedAt: new Date(),
        },
      });
    } catch (error) {
      await prisma.generation.update({
        where: { id: generationId },
        data: { status: "failed", completedAt: new Date() },
      });
      throw error;
    }
  }

  private async handleAIImprovement(job: QueueJob) {
    const { code, feedback, componentId } = job.payload;
    const improvedCode = await aiService.improveCode(code, feedback);
    await prisma.component.update({
      where: { id: componentId },
      data: {
        componentData: JSON.stringify({ code: improvedCode }),
        updatedAt: new Date(),
      },
    });
  }

  private async handleAIValidation(job: QueueJob) {
    const { code, componentId } = job.payload;
    const validation = await aiService.validateComponent(code);
    await prisma.component.update({
      where: { id: componentId },
      data: {
        componentData: JSON.stringify({
          code,
          validationResults: validation,
          validatedAt: new Date(),
        }),
      },
    });
  }

  /** Queue introspection & admin methods */
  async getQueueStats() {
    const [pending, processing, completed, failed] = await Promise.all([
      prisma.queueJob.count({ where: { status: "pending" } }),
      prisma.queueJob.count({ where: { status: "processing" } }),
      prisma.queueJob.count({ where: { status: "completed" } }),
      prisma.queueJob.count({ where: { status: "failed" } }),
    ]);

    return {
      pending,
      processing,
      completed,
      failed,
      processedCount: this.processedJobs.size,
      failedCacheSize: this.failedJobsCache.length,
    };
  }

  async getFailedJobs(limit = 50) {
    return prisma.queueJob.findMany({
      where: { status: "failed" },
      orderBy: { completedAt: "desc" },
      take: limit,
    });
  }

  async retryJob(jobId: string) {
    const job = await prisma.queueJob.findUnique({ where: { id: jobId } });
    if (!job || job.status !== "failed") {
      throw new Error("Job not found or not failed");
    }

    await prisma.queueJob.update({
      where: { id: jobId },
      data: {
        status: "pending",
        attempts: 0,
        error: null,
        scheduledFor: new Date(),
        startedAt: null,
        completedAt: null,
      },
    });

    this.processedJobs.delete(jobId);
  }

  async cleanup() {
    if (this.pollInterval) clearInterval(this.pollInterval);
    this.running = false;
    console.log("[QueueService] Cleaned up");
  }
}

export const queueService = new QueueService();
queueService.start();
export default queueService;
